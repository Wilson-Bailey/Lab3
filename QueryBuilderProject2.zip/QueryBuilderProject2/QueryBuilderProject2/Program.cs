﻿using System;
using System.Collections.Generic;
using QueryBuilderProject2;
using QueryBuilderProject2.Models;

class Program
{
    static void Main()
    {
        string dbFileName = "data.db"; 

        // Create an instance of QueryBuilder
        using (var queryBuilder = new QueryBuilder(dbFileName))
        {
            // Step 1: Erase all records for Pokemon objects
            queryBuilder.DeleteAll<Pokemon>();
            Console.WriteLine("All Pokemon records deleted from the database.");

            // Step 2: Create a collection of Pokemon objects
            var pokemonCollection = new List<Pokemon>
            {
                new Pokemon { Id = 1, Name = "Pikachu" },
                new Pokemon { Id = 2, Name = "Bulbasaur" }
                
            };

            // Write the Pokemon collection to the database
            queryBuilder.WriteCollectionToDatabase(pokemonCollection);
            Console.WriteLine("Pokemon collection written to the database successfully.");

            // Step 3: Create a collection of BannedGame objects
            var bannedGamesCollection = new List<BannedGame>
            {
                new BannedGame { Id = 1, Title = "GameX", Series = "SeriesX", Country = "France", Details = "Too much messing" },
                new BannedGame { Id = 2, Title = "GameY", Series = "SeriesY", Country = "USA", Details = "Too much nudity" }
               
            };

            // Write the BannedGame collection to the database
            queryBuilder.WriteCollectionToDatabase(bannedGamesCollection);
            Console.WriteLine("BannedGame collection written to the database successfully.");

            // Step 4: Create a single Pokemon object
            var singlePokemon = new Pokemon { Id = 3, Name = "Charmander", DexNumber = 4 };

            // Write the single Pokemon object to the database
            queryBuilder.Create(singlePokemon);
            Console.WriteLine("Single Pokemon object written to the database successfully.");

            // Step 5: Create a single BannedGame object
            var singleBannedGame = new BannedGame { Id = 3, Title = "GameZ", Series = "SeriesZ", Country = "Russia", Details = "Bad stuff man" };

            // Write the single BannedGame object to the database
            queryBuilder.Create(singleBannedGame);
            Console.WriteLine("Single BannedGame object written to the database successfully.");
        }
    }
}