﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueryBuilderProject2.Models
{
    public interface IClassModel
    {
        public int Id { get; set; }
    }
}
